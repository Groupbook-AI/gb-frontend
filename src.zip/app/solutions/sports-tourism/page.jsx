'use client'

import { useState } from 'react'
import { Hero } from '@/components/sports-tourism/Hero'
import { PrimaryFeatures } from '@/components/sports-tourism/PrimaryFeatures'
import { SecondaryFeatures } from '@/components/sports-tourism/SecondaryFeatures'
import { CallToAction } from '@/components/sports-tourism/CallToAction'
import { Reviews } from '@/components/sports-tourism/Reviews'
import { Pricing } from '@/components/sports-tourism/Pricing'
import { Faqs } from '@/components/sports-tourism/Faqs'



export default function SportsTourism() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)

  return (
    <>
      <Hero />
      <PrimaryFeatures />
      <SecondaryFeatures />
      <CallToAction />
      <Reviews />
      <Pricing />
      <Faqs />
    </>
  )
}
