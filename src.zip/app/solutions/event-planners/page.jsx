'use client'

import { useState } from 'react'
import { Hero } from '@/components/event-planners/Hero'
import { PrimaryFeatures } from '@/components/event-planners/PrimaryFeatures'
import { SecondaryFeatures } from '@/components/event-planners/SecondaryFeatures'
import { CallToAction } from '@/components/event-planners/CallToAction'
import { Reviews } from '@/components/event-planners/Reviews'
import { Pricing } from '@/components/event-planners/Pricing'
import { Faqs } from '@/components/event-planners/Faqs'

export default function Home() {
  return (
    <>
      <Hero />
      <PrimaryFeatures />
      <SecondaryFeatures />
      <CallToAction />
      <Reviews />
      <Pricing />
      <Faqs />
    </>
  )
}
