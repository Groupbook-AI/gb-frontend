'use client'

import { useState } from 'react'
import { Hero } from '@/components/dmo-cvb/Hero'
import { PrimaryFeatures } from '@/components/dmo-cvb/PrimaryFeatures'
import { SecondaryFeatures } from '@/components/dmo-cvb/SecondaryFeatures'
import { CallToAction } from '@/components/dmo-cvb/CallToAction'
import { Reviews } from '@/components/dmo-cvb/Reviews'
import { Pricing } from '@/components/dmo-cvb/Pricing'
import { Faqs } from '@/components/dmo-cvb/Faqs'

export default function Home() {
  return (
    <>
      <Hero />
      <PrimaryFeatures />
      <SecondaryFeatures />
      <CallToAction />
      <Reviews />
      <Pricing />
      <Faqs />
    </>
  )
}
