'use client'

import { useState } from 'react'
import { Hero } from '@/components/venues/Hero'
import { PrimaryFeatures } from '@/components/venues/PrimaryFeatures'
import { SecondaryFeatures } from '@/components/venues/SecondaryFeatures'
import { CallToAction } from '@/components/venues/CallToAction'
import { Reviews } from '@/components/venues/Reviews'
import { Pricing } from '@/components/venues/Pricing'
import { Faqs } from '@/components/venues/Faqs'

export default function Home() {
  return (
    <>
      <Hero />
      <PrimaryFeatures />
      <SecondaryFeatures />
      <CallToAction />
      <Reviews />
      <Pricing />
      <Faqs />
    </>
  )
}
