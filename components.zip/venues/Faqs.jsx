import { Container } from '@/components/Container'

const faqs = [
  [
    {
      question: 'How can I make it easier for my clients to find hotel accommodations near my venue?',
      answer:
        'Groupbook simplifies the process by providing clients with curated hotel options based on proximity, availability, and budget, ensuring seamless coordination between your venue and their lodging needs.',
    },
    {
      question: 'Why do my clients complain about hotel rates being too high?',
      answer:
        'Many clients lack the resources to negotiate favorable rates. Groupbook leverages its network to secure competitive group rates, offering value to your clients and enhancing your venue’s reputation.',
    },
    {
      question: 'How can I earn commissions on hotel bookings made by clients hosting events at my venue?',
      answer:
        'Groupbook provides a commission structure for venue owners, allowing you to monetize hotel bookings seamlessly through our platform while providing added value to your clients.',
    },
  ],
  [
    {
      question: 'What if my clients need help managing multiple room blocks for a single event?',
      answer:
        'Groupbook’s platform allows clients to manage multiple blocks in one dashboard, making it easy to track availability, bookings, and deadlines for all hotels involved.',
    },
    {
      question: 'How can I provide extra value to event organizers using my venue?',
      answer:
        'By partnering with Groupbook, you can offer organizers access to exclusive hotel deals, perks, and concierge services, positioning your venue as a one-stop solution for event success.',
    },
    {
      question: 'How can I make sure my clients have a seamless booking experience?',
      answer:
        'Groupbook provides an intuitive platform that simplifies the booking process, offering clients a smooth experience from start to finish, with dedicated support available for every step.',
    },
  ],
  [
    {
      question: 'How can I track all hotel bookings for events at my venue?',
      answer:
        'Groupbook’s centralized dashboard allows you to easily monitor all hotel bookings associated with events at your venue, ensuring you stay up-to-date with availability and reservations.',
    },
    {
      question: 'What if my clients have specific requests for their hotel accommodations?',
      answer:
        'Groupbook allows for customization within room blocks, so you can accommodate specific client requests like room types, dates, and special preferences while keeping the group benefits intact.',
    },
    {
      question: 'Can Groupbook integrate with my venue management system?',
      answer:
        'Yes, Groupbook can integrate with your venue management system, ensuring seamless coordination between your event logistics and hotel accommodations without the need for duplicate efforts.',
    },
  ],
];



export function Faqs() {
  return (
    <section
      id="faqs"
      aria-labelledby="faqs-title"
      className="border-t border-gray-200 py-20 sm:py-32"
    >
      <Container>
        <div className="mx-auto max-w-2xl lg:mx-0">
          <h2
            id="faqs-title"
            className="text-3xl font-medium tracking-tight text-gray-900"
          >
            Frequently Asked Questions
          </h2>
          <p className="mt-2 text-lg text-gray-600">
            If you have anything else you want to ask,{' '}
            <a
              href="mailto:info@example.com"
              className="text-gray-900 underline"
            >
              reach out to us
            </a>
            .
          </p>
        </div>
        <ul
          role="list"
          className="mx-auto mt-16 grid max-w-2xl grid-cols-1 gap-8 sm:mt-20 lg:max-w-none lg:grid-cols-3"
        >
          {faqs.map((column, columnIndex) => (
            <li key={columnIndex}>
              <ul role="list" className="space-y-10">
                {column.map((faq, faqIndex) => (
                  <li key={faqIndex}>
                    <h3 className="text-lg font-semibold leading-6 text-gray-900">
                      {faq.question}
                    </h3>
                    <p className="mt-4 text-sm text-gray-700">{faq.answer}</p>
                  </li>
                ))}
              </ul>
            </li>
          ))}
        </ul>
      </Container>
    </section>
  )
}
