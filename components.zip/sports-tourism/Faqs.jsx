import { Container } from '@/components/Container'

const faqs = [
  [
    {
      question: 'Why do I struggle to secure affordable rooms for my team during tournaments?',
      answer:
        'Hotels often raise rates during events or prioritize individual bookings. Groupbook ensures teams get fair group rates by negotiating directly with hotels, so your players and families don’t overpay.',
    },
    {
      question: 'How can I ensure everyone on my team books their room within the block?',
      answer:
        'Groupbook provides an easy-to-use dashboard for team leads to monitor bookings. You’ll also receive automated reminders to keep everyone on track, ensuring full utilization of the block.',
    },
    {
      question: 'Why haven’t I been able to earn commissions for coordinating team hotel bookings?',
      answer:
        'Teams rarely see commission opportunities without complex agreements. With Groupbook, commissions are built into the process, rewarding you for organizing accommodations without extra work.',
    },
  ],
  [
    {
      question: 'How do I handle players and families needing different booking dates or room types?',
      answer:
        'Groupbook allows customization within blocks, so your team can select specific dates and room types that fit their needs while keeping the group benefits intact.',
    },
    {
      question: 'What happens if the hotel cancels or changes our block?',
      answer:
        'Groupbook monitors all blocks and ensures backups are available if disruptions occur. Our concierge team proactively resolves issues, so your team stays focused on the game.',
    },
    {
      question: 'How do I ensure my team’s accommodations are close to the venue?',
      answer:
        'Groupbook helps you choose hotels within a desired radius of the venue, ensuring your team stays close to the action and minimizing travel time between events.',
    },
  ],
  [
    {
      question: 'Can I track all bookings for my team in one place?',
      answer:
        'Yes, Groupbook provides a comprehensive dashboard where you can track all room bookings, monitor availability, and make adjustments as needed—saving you time and hassle.',
    },
    {
      question: 'How can I avoid last-minute cancellations or no-shows?',
      answer:
        'Groupbook offers automated reminders for team members to confirm their bookings, reducing the chances of cancellations or no-shows and helping you maintain a full block.',
    },
    {
      question: 'How do I make adjustments to a booking if something changes?',
      answer:
        'Groupbook’s user-friendly interface allows you to easily modify bookings, whether you need to update room types, extend dates, or accommodate changes in team size.',
    },
  ],
];



export function Faqs() {
  return (
    <section
      id="faqs"
      aria-labelledby="faqs-title"
      className="border-t border-gray-200 py-20 sm:py-32"
    >
      <Container>
        <div className="mx-auto max-w-2xl lg:mx-0">
          <h2
            id="faqs-title"
            className="text-3xl font-medium tracking-tight text-gray-900"
          >
            Frequently Asked Questions
          </h2>
          <p className="mt-2 text-lg text-gray-600">
            If you have anything else you want to ask,{' '}
            <a
              href="mailto:info@example.com"
              className="text-gray-900 underline"
            >
              reach out to us
            </a>
            .
          </p>
        </div>
        <ul
          role="list"
          className="mx-auto mt-16 grid max-w-2xl grid-cols-1 gap-8 sm:mt-20 lg:max-w-none lg:grid-cols-3"
        >
          {faqs.map((column, columnIndex) => (
            <li key={columnIndex}>
              <ul role="list" className="space-y-10">
                {column.map((faq, faqIndex) => (
                  <li key={faqIndex}>
                    <h3 className="text-lg font-semibold leading-6 text-gray-900">
                      {faq.question}
                    </h3>
                    <p className="mt-4 text-sm text-gray-700">{faq.answer}</p>
                  </li>
                ))}
              </ul>
            </li>
          ))}
        </ul>
      </Container>
    </section>
  )
}
